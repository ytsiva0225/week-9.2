MySQL JDBC Insert Users Example

1. Ensure MySQL is running and database `mydatabase` already exists.
2. In MySQLJDBCInsertUsers.java, change USERNAME and PASSWORD to your
   MySQL credentials. Replace `your_password` with your actual password.
3. Add MySQL Connector/J to your project's classpath.
4. Compile and run MySQLJDBCInsertUsers.java.

The program creates the `users` table if needed and inserts John Doe and
Jane Doe using PreparedStatement. Running it repeatedly inserts the two
records again each time.
